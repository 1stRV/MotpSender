package ru.x5.motpsender.dao.dto;

import lombok.Data;

@Data
public class GetProducerInnResponse {
    private String inn;
}
