package ru.x5.motpsender.dao.helper;

import java.io.IOException;

public interface MotpHelper {

    void prepareTestData() throws IOException;
}
